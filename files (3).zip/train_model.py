import subprocess
import sys
import os
import torch
import urllib.request


# ─────────────────────────────────────────────
# 1.  Paths & settings
# ─────────────────────────────────────────────
YOLOV5_DIR      = "yolov5"                        # cloned repo
WEIGHTS_DIR     = "models"
PRETRAINED_WEIGHTS = os.path.join(WEIGHTS_DIR, "yolov5s.pt")
DATA_YAML       = "configs/data.yaml"
MODEL_YAML      = "configs/model.yaml"
TRAINING_YAML   = "configs/training.yaml"


# ─────────────────────────────────────────────
# 2.  Clone YOLOv5 repo (if not already cloned)
# ─────────────────────────────────────────────
def setup_yolov5():
    if not os.path.exists(YOLOV5_DIR):
        print("[INFO] Cloning YOLOv5 repository...")
        subprocess.run(
            ["git", "clone", "https://github.com/ultralytics/yolov5.git", YOLOV5_DIR],
            check=True
        )
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "-r",
             os.path.join(YOLOV5_DIR, "requirements.txt")],
            check=True
        )
    else:
        print("[INFO] YOLOv5 repo already exists, skipping clone.")


# ─────────────────────────────────────────────
# 3.  Download COCO pre-trained weights
# ─────────────────────────────────────────────
def download_pretrained_weights():
    os.makedirs(WEIGHTS_DIR, exist_ok=True)
    if not os.path.exists(PRETRAINED_WEIGHTS):
        url = "https://github.com/ultralytics/yolov5/releases/download/v7.0/yolov5s.pt"
        print(f"[INFO] Downloading COCO pre-trained weights from:\n  {url}")
        urllib.request.urlretrieve(url, PRETRAINED_WEIGHTS)
        print(f"[INFO] Saved to: {PRETRAINED_WEIGHTS}")

        # Verify file
        size_mb = os.path.getsize(PRETRAINED_WEIGHTS) / 1e6
        print(f"[INFO] Weights file size: {size_mb:.1f} MB")
        assert size_mb > 10, "Downloaded file seems too small — check the URL!"
    else:
        print(f"[INFO] Pre-trained weights already exist: {PRETRAINED_WEIGHTS}")


# ─────────────────────────────────────────────
# 4.  Verify directory structure
# ─────────────────────────────────────────────
def verify_structure():
    required = [
        WEIGHTS_DIR,
        "configs",
        "data/images/train",
        "data/images/val",
        "data/labels/train",
        "data/labels/val",
    ]
    print("\n[INFO] Verifying directory structure...")
    all_ok = True
    for path in required:
        exists = os.path.exists(path)
        status = "✅" if exists else "❌  MISSING"
        print(f"  {status}  {path}")
        if not exists:
            all_ok = False

    if not all_ok:
        print("\n[WARNING] Some directories are missing. Creating them now...")
        for path in required:
            os.makedirs(path, exist_ok=True)
    else:
        print("[INFO] All directories OK.\n")


# ─────────────────────────────────────────────
# 5.  Read hyperparams from training.yaml
# ─────────────────────────────────────────────
def load_training_config(yaml_path=TRAINING_YAML):
    import yaml
    with open(yaml_path, 'r') as f:
        cfg = yaml.safe_load(f)
    return cfg


# ─────────────────────────────────────────────
# 6.  Launch YOLOv5 training (transfer learning)
# ─────────────────────────────────────────────
def train():
    setup_yolov5()
    download_pretrained_weights()
    verify_structure()

    cfg = load_training_config()

    device = "0" if torch.cuda.is_available() else "cpu"
    print(f"[INFO] Training on device: {'GPU (cuda:0)' if device == '0' else 'CPU'}\n")

    cmd = [
        sys.executable,
        os.path.join(YOLOV5_DIR, "train.py"),
        "--img",     str(cfg.get("img_size", 640)),
        "--batch",   str(cfg.get("batch_size", 16)),
        "--epochs",  str(cfg.get("epochs", 50)),
        "--data",    DATA_YAML,
        "--cfg",     MODEL_YAML,
        "--weights", PRETRAINED_WEIGHTS,   # ← COCO pre-trained (transfer learning)
        "--lr0",     str(cfg.get("learning_rate", 0.001)),
        "--device",  device,
        "--project", "runs/train",
        "--name",    "kitti_yolov5s",
        "--exist-ok",
    ]

    print("[INFO] Starting training with command:")
    print("  " + " ".join(cmd) + "\n")
    subprocess.run(cmd, check=True)


# ─────────────────────────────────────────────
# 7.  Entry point
# ─────────────────────────────────────────────
if __name__ == "__main__":
    train()
