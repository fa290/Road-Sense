import os
import cv2
import torch
import numpy as np
from torch.utils.data import Dataset, random_split
import albumentations as A
from albumentations.pytorch import ToTensorV2

# KITTI class mapping → YOLO index
KITTI_CLASSES = {
    'Car': 0,
    'Pedestrian': 1,
    'Cyclist': 2
}


def convert_kitti_to_yolo(label_lines, img_w, img_h):
    """
    Convert KITTI label format to YOLO format.
    KITTI: type truncated occluded alpha x1 y1 x2 y2 ...
    YOLO:  class cx cy w h  (all normalized 0-1)
    """
    yolo_labels = []
    for line in label_lines:
        parts = line.strip().split()
        if not parts:
            continue
        obj_type = parts[0]
        if obj_type not in KITTI_CLASSES:
            continue  # skip DontCare, Van, Truck, etc.

        cls_id = KITTI_CLASSES[obj_type]
        x1, y1, x2, y2 = float(parts[4]), float(parts[5]), float(parts[6]), float(parts[7])

        # Normalize to 0-1
        cx = ((x1 + x2) / 2) / img_w
        cy = ((y1 + y2) / 2) / img_h
        w  = (x2 - x1) / img_w
        h  = (y2 - y1) / img_h

        yolo_labels.append([cls_id, cx, cy, w, h])

    return torch.tensor(yolo_labels, dtype=torch.float32) if yolo_labels else torch.zeros((0, 5))


def get_transforms(train=True, img_size=640):
    if train:
        return A.Compose([
            A.Resize(img_size, img_size),
            A.HorizontalFlip(p=0.5),
            A.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2, p=0.4),
            A.GaussNoise(p=0.2),
            A.Normalize(mean=(0.485, 0.456, 0.406),
                        std=(0.229, 0.224, 0.225)),
            ToTensorV2(),
        ])
    else:
        return A.Compose([
            A.Resize(img_size, img_size),
            A.Normalize(mean=(0.485, 0.456, 0.406),
                        std=(0.229, 0.224, 0.225)),
            ToTensorV2(),
        ])


class KITTIDataset(Dataset):
    def __init__(self, images_dir, labels_dir, img_size=640, train=True):
        self.images_dir = images_dir
        self.labels_dir = labels_dir
        self.img_size   = img_size
        self.transform  = get_transforms(train=train, img_size=img_size)

        # Only keep images that have a matching label file
        all_files = sorted(os.listdir(images_dir))
        self.image_files = [
            f for f in all_files
            if f.endswith(('.jpg', '.png')) and
               os.path.exists(os.path.join(labels_dir, f.replace('.jpg', '.txt').replace('.png', '.txt')))
        ]

        if not self.image_files:
            raise RuntimeError(f"No matched image-label pairs found in {images_dir}")

    def __len__(self):
        return len(self.image_files)

    def __getitem__(self, idx):
        img_name   = self.image_files[idx]
        img_path   = os.path.join(self.images_dir, img_name)
        label_path = os.path.join(self.labels_dir,
                                  img_name.replace('.jpg', '.txt').replace('.png', '.txt'))

        # Load image
        image = cv2.imread(img_path)
        if image is None:
            raise FileNotFoundError(f"Could not read image: {img_path}")
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        img_h, img_w = image.shape[:2]

        # Load & convert labels
        with open(label_path, 'r') as f:
            lines = f.readlines()
        labels = convert_kitti_to_yolo(lines, img_w, img_h)

        # Apply transforms
        augmented = self.transform(image=image)
        image = augmented['image']  # Tensor [C, H, W]

        return image, labels


def get_datasets(images_dir, labels_dir, img_size=640, val_split=0.2, seed=42):
    """
    Returns train_dataset, val_dataset split from full dataset.
    """
    full_dataset = KITTIDataset(images_dir, labels_dir, img_size=img_size, train=True)

    val_size   = int(len(full_dataset) * val_split)
    train_size = len(full_dataset) - val_size

    train_dataset, val_dataset = random_split(
        full_dataset,
        [train_size, val_size],
        generator=torch.Generator().manual_seed(seed)
    )

    # Val dataset uses val transforms (no augmentation)
    val_dataset.dataset.transform = get_transforms(train=False, img_size=img_size)

    print(f"Dataset split → Train: {train_size} | Val: {val_size}")
    return train_dataset, val_dataset
