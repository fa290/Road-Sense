"""
Validation Data Loader — for monitoring during/after training.
Uses the same KITTIDataset with val transforms (no augmentation).
"""

import torch
from torch.utils.data import DataLoader
from data_loader import KITTIDataset, get_transforms


def get_val_loader(images_dir, labels_dir, img_size=640, batch_size=16, num_workers=4):
    """
    Returns a DataLoader for the validation set.
    No augmentation — only resize + normalize.
    """
    val_dataset = KITTIDataset(
        images_dir=images_dir,
        labels_dir=labels_dir,
        img_size=img_size,
        train=False        # ← val transforms only
    )

    val_loader = DataLoader(
        val_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=torch.cuda.is_available(),
        collate_fn=collate_fn,
    )

    print(f"[INFO] Validation loader ready — {len(val_dataset)} samples, "
          f"{len(val_loader)} batches (batch_size={batch_size})")
    return val_loader


def collate_fn(batch):
    """
    Custom collate to handle variable-length label tensors per image.
    Returns:
        images: Tensor [B, C, H, W]
        labels: list of Tensors [N_i, 5]
    """
    images, labels = zip(*batch)
    images = torch.stack(images, dim=0)
    return images, list(labels)


# ─────────────────────────────────────────────
# Quick sanity check
# ─────────────────────────────────────────────
if __name__ == "__main__":
    import sys

    images_dir = sys.argv[1] if len(sys.argv) > 1 else "data/images/val"
    labels_dir = sys.argv[2] if len(sys.argv) > 2 else "data/labels/val"

    loader = get_val_loader(images_dir, labels_dir)

    images, labels = next(iter(loader))
    print(f"[OK] Batch images shape : {images.shape}")
    print(f"[OK] Labels in batch    : {[l.shape for l in labels]}")
