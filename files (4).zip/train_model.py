import subprocess
import sys
import os
import argparse
import torch
import urllib.request


# ─────────────────────────────────────────────
# 1.  Paths
# ─────────────────────────────────────────────
YOLOV5_DIR         = "yolov5"
WEIGHTS_DIR        = "models"
PRETRAINED_WEIGHTS = os.path.join(WEIGHTS_DIR, "yolov5s.pt")
DATA_YAML          = "configs/data.yaml"
MODEL_YAML         = "configs/model.yaml"


# ─────────────────────────────────────────────
# 2.  CLI Arguments
# ─────────────────────────────────────────────
def parse_args():
    parser = argparse.ArgumentParser(description="Train YOLOv5 on KITTI dataset")
    parser.add_argument(
        "--mode",
        choices=["transfer", "scratch"],
        default="transfer",
        help="'transfer' = COCO pretrained weights | 'scratch' = random init (baseline)"
    )
    return parser.parse_args()


# ─────────────────────────────────────────────
# 3.  Setup YOLOv5 repo
# ─────────────────────────────────────────────
def setup_yolov5():
    if not os.path.exists(YOLOV5_DIR):
        print("[INFO] Cloning YOLOv5 repository...")
        subprocess.run(
            ["git", "clone", "https://github.com/ultralytics/yolov5.git", YOLOV5_DIR],
            check=True
        )
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "-r",
             os.path.join(YOLOV5_DIR, "requirements.txt")],
            check=True
        )
    else:
        print("[INFO] YOLOv5 repo already exists.")


# ─────────────────────────────────────────────
# 4.  Download COCO pretrained weights
# ─────────────────────────────────────────────
def download_pretrained_weights():
    os.makedirs(WEIGHTS_DIR, exist_ok=True)
    if not os.path.exists(PRETRAINED_WEIGHTS):
        url = "https://github.com/ultralytics/yolov5/releases/download/v7.0/yolov5s.pt"
        print(f"[INFO] Downloading COCO pre-trained weights...")
        urllib.request.urlretrieve(url, PRETRAINED_WEIGHTS)
        size_mb = os.path.getsize(PRETRAINED_WEIGHTS) / 1e6
        print(f"[INFO] Downloaded: {size_mb:.1f} MB → {PRETRAINED_WEIGHTS}")
        assert size_mb > 10, "File too small — check download!"
    else:
        print(f"[INFO] Weights already exist: {PRETRAINED_WEIGHTS}")


# ─────────────────────────────────────────────
# 5.  Verify + create directory structure
# ─────────────────────────────────────────────
def verify_structure(checkpoint_dir, logs_dir):
    required = [
        WEIGHTS_DIR,
        "configs",
        "data/images/train",
        "data/images/val",
        "data/labels/train",
        "data/labels/val",
        checkpoint_dir,
        logs_dir,
    ]
    print("\n[INFO] Verifying directory structure...")
    for path in required:
        os.makedirs(path, exist_ok=True)
        print(f"  ✅  {path}")
    print()


# ─────────────────────────────────────────────
# 6.  Load config yaml
# ─────────────────────────────────────────────
def load_config(yaml_path):
    import yaml
    with open(yaml_path, 'r') as f:
        return yaml.safe_load(f)


# ─────────────────────────────────────────────
# 7.  Train
# ─────────────────────────────────────────────
def train(mode="transfer"):
    setup_yolov5()

    if mode == "transfer":
        config_path = "configs/training.yaml"
        weights     = PRETRAINED_WEIGHTS
        run_name    = "kitti_transfer_learning"
        print("\n" + "="*55)
        print("  MODE: Transfer Learning (COCO pretrained weights)")
        print("="*55 + "\n")
        download_pretrained_weights()

    else:  # scratch
        config_path = "configs/training_scratch.yaml"
        weights     = ""           # empty = random init in YOLOv5
        run_name    = "kitti_from_scratch"
        print("\n" + "="*55)
        print("  MODE: From Scratch (random weight initialization)")
        print("="*55 + "\n")

    cfg            = load_config(config_path)
    checkpoint_dir = cfg.get("checkpoint_dir", f"models/checkpoints/{mode}")
    logs_dir       = cfg.get("logs_dir",       f"models/logs/{mode}")
    verify_structure(checkpoint_dir, logs_dir)

    device = "0" if torch.cuda.is_available() else "cpu"
    print(f"[INFO] Device : {'GPU (cuda:0)' if device == '0' else 'CPU'}")
    print(f"[INFO] Epochs : {cfg.get('epochs')}  |  LR: {cfg.get('learning_rate')}  |  Batch: {cfg.get('batch_size')}\n")

    cmd = [
        sys.executable,
        os.path.join(YOLOV5_DIR, "train.py"),
        "--img",         str(cfg.get("img_size", 640)),
        "--batch",       str(cfg.get("batch_size", 16)),
        "--epochs",      str(cfg.get("epochs", 100)),
        "--data",        DATA_YAML,
        "--cfg",         MODEL_YAML,
        "--weights",     weights,
        "--lr0",         str(cfg.get("learning_rate", 0.01)),
        "--device",      device,
        "--project",     "runs/train",
        "--name",        run_name,
        "--exist-ok",
        "--save-period", str(cfg.get("save_period", 10)),
    ]

    # Pass aggressive augmentation hyp file for scratch mode
    if mode == "scratch":
        cmd += ["--hyp", config_path]

    print("[INFO] Running command:")
    print("  " + " ".join(cmd) + "\n")
    subprocess.run(cmd, check=True)

    print(f"\n[DONE] Training complete!")
    print(f"  Checkpoints → {checkpoint_dir}")
    print(f"  Logs        → {logs_dir}")


# ─────────────────────────────────────────────
# 8.  Entry point
# ─────────────────────────────────────────────
if __name__ == "__main__":
    args = parse_args()
    train(mode=args.mode)
